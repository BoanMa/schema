module.exports = {
    CONNECT: "connect",
    DISCONNECT: "disconnect",
    CHAT_MESSAGE : "chat_message",
    JOIN_USER : "join_user",
    USER_JOINED : "user_joined",
    NEW_ONLINE_USER : "new online user"
};